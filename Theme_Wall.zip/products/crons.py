

def printHello():
    print("Hellttgtytyo")

printHello()